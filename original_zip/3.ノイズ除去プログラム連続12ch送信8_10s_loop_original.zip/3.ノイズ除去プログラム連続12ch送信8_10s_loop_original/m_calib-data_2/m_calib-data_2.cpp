// sumi2.cpp : �R���\�[�� �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

/*
#define _USE_MATH_DEFINES
*/

#include "stdafx.h"
#include<stdlib.h>
#include<math.h>
#include<stdio.h>
#include<float.h>

#define CL 60.0    //�R�C����[m]
#define L  337.5    //���W���S����R�C���̒��S�܂ł̒���[m]
#define NUM_SEND 8
/*
#define M_PI 3.141592653589793
*/
#define PATERN 1
#define FILENUM 1  //�f�[�^�Z�b�g�̐�
#define EXIST_CSF_FILENUM 1
#define calib_point 2497
#define Switch 0
#define N 27//�f�[�^�Z�b�g������̃f�[�^��
#define v_switch 1//�X���̐؂�ւ��@����0�\��
#define START_CH_NO 1
#define END_CH_NO 12
#define NUM_CH (END_CH_NO  - START_CH_NO + 1)
#define REF_CH 2

#define MOV_DATA_DATE "20250304"
#define START_DATA_NO 10801
#define END_DATA_NO   10802
/*
#define MOV_DATA_DIR "..\\..\\data\\2015110911mov"
#define FILE_NAME_BEFORE_FILE_NO "AD2015110911"
*/
#define CSF_DIR "..\\..\\data\\20250304\\c-mean"


double **new_matrix(int m, int n)
{
  int i,j;
  double **a;
  a = (double **)malloc(sizeof(double *) * m);
  for (i = 0; i < m; i++)
	  a[i] = (double *)malloc(sizeof(double) * n);

for(i=0;i<m;i++){
	for(j=0;j<n;j++){
		a[i][j]=0;
		}
	}
  return a;
}
int min_index(double *S,int i1,int i2){
int i,j;
double C;
j=i1;
C=S[i1];
for(i=i1+1;i<i2;i++){
	if(S[i] < C){
//printf("%d\n",i);
		j=i;
		C=S[i];
		}
	}

return(j);
}
int max_index(double *S,int i1,int i2){
int i,j;
double C;
j=i1;
C=S[i1];
for(i=i1+1;i<i2;i++){
	if(S[i] > C){
		j=i;
		C=S[i];
		}
	}

return(j);
}
void free_matrix(double **a,int m)
{
	int i;

	for (i = 0; i < m; i++){
		free(a[i]);
//		printf("%dunnnko\n",i);
		a[i]=NULL;
	}

	free(a);
	a=NULL;
}
void sai1(double *x,double *y,double *z,double *z2,int I)
{
        int i;
        double a0,a1,p,q;
        double A00,A01,A02,A11,A12;

        //FILE *output1;
       // FILE *output2;

        //output1=fopen("output1.data","w");
        //output2=fopen("output2.data","w");


		
	//puts("ok");

	//scanf("%d",&i);



        A00=A01=A02=A11=A12=0.0;

        for (i=0;i<calib_point;i++) {
                A00+=1.0;
                A01+=x[i];
                A02+=y[i];
                A11+=x[i]*x[i];
                A12+=x[i]*y[i];
        }

		/*�P�����̌W���̌v�Z*/
        a0=(A02*A11-A01*A12)/(A00*A11-A01*A01);
        a1=(A00*A12-A01*A02)/(A00*A11-A01*A01);

		z[I]=a1;
		z2[I]=a0;

/*gnuplot�ŃO���t�\���̂��߂Ƀf�[�^���t�@�C���ɕۑ�*/
       // for(i=0;i<N;i++) {
        //        fprintf(output1,"%f %f\n",x[i],y[i]);
     //   }

/*gnuplot�ŃO���t�\���̂��߂ɁA�v�Z�œ���ꂽ�P�����Ńf�[�^�ߕӂ̃O���t�f�[�^��ۑ�*/
        for(p=x[0]-10.0;p<x[calib_point-1]+10.0;p+=0.01) {
                q=a0+a1*p;
         //       fprintf(output2,"%f %f\n",p,q);
        }

       // fclose(output1);
       // fclose(output2);

}
void sai2(double *x,double *y,double *z,double *z2,int I)
{
        int i;
        double a0,a1,p,q;
        double A00,A01,A02,A11,A12;

        //FILE *output1;
       // FILE *output2;

        //output1=fopen("output1.data","w");
        //output2=fopen("output2.data","w");


		
	//puts("ok");

	//scanf("%d",&i);



        A00=A01=A02=A11=A12=0.0;

        for (i=0;i<calib_point*FILENUM;i++) {
                A00+=1.0;
                A01+=x[i];
                A02+=y[i];
                A11+=x[i]*x[i];
                A12+=x[i]*y[i];
        }

		/*�P�����̌W���̌v�Z*/
        a0=(A02*A11-A01*A12)/(A00*A11-A01*A01);
        a1=(A00*A12-A01*A02)/(A00*A11-A01*A01);

		z[I]=a1;
		z2[I]=a0;

/*gnuplot�ŃO���t�\���̂��߂Ƀf�[�^���t�@�C���ɕۑ�*/
       // for(i=0;i<N;i++) {
        //        fprintf(output1,"%f %f\n",x[i],y[i]);
     //   }

/*gnuplot�ŃO���t�\���̂��߂ɁA�v�Z�œ���ꂽ�P�����Ńf�[�^�ߕӂ̃O���t�f�[�^��ۑ�*/
        for(p=x[0]-10.0;p<x[calib_point*FILENUM-1]+10.0;p+=0.01) {
                q=a0+a1*p;
         //       fprintf(output2,"%f %f\n",p,q);
        }

       // fclose(output1);
       // fclose(output2);

}
void sort(double **new_d_buf,double **d_buf)
{
	int i,j,k;
	int MIN;

	for(i=0;i<NUM_SEND;i++)
	{
		for(j=0;j<calib_point;j++)
		{

			MIN=min_index(d_buf[2*i],0,calib_point);

			new_d_buf[2*i][j]=d_buf[2*i][MIN];
			new_d_buf[2*i+1][j]=d_buf[2*i+1][MIN];

			d_buf[2*i][MIN]=DBL_MAX;
			//printf("%f:%f\n",new_d_buf[2*i][j],new_d_buf[2*i+1][j]);
		}
	}

}
void sort2(double **new_d_buf,double **d_buf)
{
	int i,j,k;
	int MIN;

	for(i=0;i<NUM_SEND;i++)
	{
		for(j=0;j<calib_point*FILENUM;j++)
		{

			MIN=min_index(d_buf[2*i],0,calib_point*FILENUM);

			new_d_buf[2*i][j]=d_buf[2*i][MIN];
			new_d_buf[2*i+1][j]=d_buf[2*i+1][MIN];

			d_buf[2*i][MIN]=DBL_MAX;
			//printf("%f:%f\n",new_d_buf[2*i][j],new_d_buf[2*i+1][j]);
		}
	}

}
void fitting(double **cmp_data,double *s1,double *s2)
{
	int i,j,k;

	for(i=0;i<NUM_SEND;i++)
	{
		for(j=0;j<calib_point;j++)
		{
			cmp_data[2*i][j]=cmp_data[2*i][j] - s1[i];
			cmp_data[2*i+1][j]=cmp_data[2*i+1][j] - s2[i];
		}
	}
}

void fitting2(double **cmp_data,double *v,double **mean_data)
{
	int i,j,k,s;

	for(s=0;s<FILENUM;s++)
	{
		for(i=0;i<NUM_SEND;i++)
		{
			for(j=0;j<calib_point;j++)
			{		
				mean_data[i][j+s*calib_point] = (cmp_data[2*i][j+s*calib_point] + cmp_data[2*i+1][j+s*calib_point]*v[i])
	           		                            /pow((1.0+pow(v[i],2.0)),0.5);
			}
		}
	}
}

void fitting3(double **cmp_data,double **cst,double **mean_data)
{
	int i,j,k,s;

	for(s=0;s<FILENUM;s++)
	{
		for(i=0;i<NUM_SEND;i++)
		{
			for(j=0;j<calib_point;j++)
			{
				mean_data[i][j+s*calib_point]=(cmp_data[2*i][j+s*calib_point] + cmp_data[2*i+1][j+s*calib_point]*cst[s][i])/pow((1.0+pow(cst[s][i],2.0)),0.5);
			}
		}
	}
}


int main()
{


	FILE *in_fp[FILENUM],*out_fp[FILENUM],*old_fp[FILENUM],*cst_fp;

	int i, i_ch, j,s;
	int i_data_no;
	int use_cst_file, filenum_in_cst, use_file_no;
	char d_name[256], di_dir[256], b_di_name[256], a_di_name[256], cst_file_name[256];
	char f_name[256], csf_dir[256];
//	double cst[6], cst2[6];
	double cst_total[NUM_SEND], cst2_total[NUM_SEND];
	double **d_buf,**d_buf2, **d_buf_total, **d_buf_total2;
	double **new_d_buf, **new_d_buf_total;
	double **cmp_data,**mean_data,**old_mean_data;
	double **cst,**cst2;
	double v[NUM_SEND];
	double sum=0;
	double a;

	/* �̈�m�� */
	mean_data     =  new_matrix(NUM_SEND,calib_point*FILENUM);
	old_mean_data =  new_matrix(NUM_SEND,calib_point*FILENUM);
	d_buf         =  new_matrix(2 * NUM_SEND,calib_point);
	d_buf2        =  new_matrix(2 * NUM_SEND,calib_point);
	new_d_buf     =  new_matrix(2 * NUM_SEND,calib_point);
	d_buf_total   =  new_matrix(2 * NUM_SEND,calib_point*FILENUM);
	d_buf_total2  =  new_matrix(2 * NUM_SEND,calib_point*FILENUM);
	new_d_buf_total = new_matrix(2 * NUM_SEND, calib_point * FILENUM);
	cmp_data      =  new_matrix(2 * NUM_SEND,calib_point*FILENUM);
	cst           =  new_matrix(FILENUM,NUM_SEND);
	cst2          =  new_matrix(FILENUM,NUM_SEND);

	use_cst_file = 1;
//	printf("Please input CST file_directory\n");
	sprintf(csf_dir, "%s", CSF_DIR);


	for (i_data_no = START_DATA_NO; i_data_no <= END_DATA_NO; i_data_no++) {
		sprintf(di_dir, "..\\..\\data\\%s/%s%05dmov", MOV_DATA_DATE, MOV_DATA_DATE, i_data_no);
		sprintf(b_di_name, "AD%s%05d", MOV_DATA_DATE, i_data_no);
		printf("data_no = %d\n", i_data_no);
		//	printf("put_input_directory\n");//���̓t�@�C�����̓���(md4cal)
		//  scanf("%s", di_dir);
		//	printf("put_input_file_name_before_file_no\n");//���̓t�@�C�����̓���(md4cal)
		//	scanf("%s", b_di_name);
		//	printf("put_input_file_name_after_file_no\n");
		//	scanf("%s", a_di_name);

		//	printf("put_output_file\n");//�o�̓t�@�C�����̓���
		//	scanf("%s",d_name);

		//	printf("Do you use the existed cst file?(Yes = 1, No = others)\n");
		//	scanf("%d", &use_cst_file);

		for (i_ch = START_CH_NO; i_ch <= END_CH_NO; i_ch++) {
			if (i_ch == REF_CH)
				continue;
			for (i = 0; i < FILENUM; i++)
			{
				sprintf(f_name, "%s\\%s_%d_%dch.data", di_dir, b_di_name, i, i_ch);//���̓t�@�C���̃I�[�v��	
				in_fp[i] = fopen(f_name, "r");

				sprintf(f_name, "%s\\%s_out_%d_ch%d.data", di_dir, b_di_name, i, i_ch);//�o�̓t�@�C���̃I�[�v��	
				out_fp[i] = fopen(f_name, "w");

				sprintf(f_name, "%s\\%s_out_%d_ch%d-old.data", di_dir, b_di_name, i, i_ch);
				old_fp[i] = fopen(f_name, "w");
			}

			if (use_cst_file == 1) {
				sprintf(f_name, "%s\\out_ch%d_cst.data", csf_dir, i_ch);
				cst_fp = fopen(f_name, "r");
				for (i = 0; i < NUM_SEND; i++)
					fscanf(cst_fp, "%lf\t", &cst[0][i]);
				fscanf(cst_fp, "\n");
				fscanf(cst_fp, "\n");
				for (i = 0; i < NUM_SEND; i++)
					fscanf(cst_fp, "%lf\t", &cst2[0][i]);
				fscanf(cst_fp, "\n");
			}
			else {
				sprintf(f_name, "%s\\%s_out_ch%d_cst.data", di_dir, b_di_name, i_ch);
				cst_fp = fopen(f_name, "w");
			}

			for (s = 0; s < FILENUM; s++)
			{
				/*(����+����)*K �̐��l��buf�Ɋi�[ */
				for (i = 0; i < calib_point; i++) {
					for (j = 0; j < NUM_SEND - 1; j++)
						fscanf(in_fp[s], "%lf\t%lf\t", &d_buf[2 * j][i], &d_buf[2 * j + 1][i]);
					fscanf(in_fp[s], "%lf\t%lf\n", &d_buf[2 * (NUM_SEND - 1)][i], &d_buf[2 * (NUM_SEND - 1) + 1][i]);
					for (j = 0; j < 2 * NUM_SEND; j++) {
						d_buf2[j][i] = d_buf[j][i];
						d_buf_total[j][i + s * calib_point] = d_buf_total2[j][i + s * calib_point] = d_buf[j][i];
					}
				}

				if (use_cst_file != 1) {

					/* ��A�������������߂Ɂi�����A�����j�̃f�[�^�������̑傫�����ɕ��ёւ� */
					sort(new_d_buf, d_buf);

					for (i = 0; i < NUM_SEND; i++)
					{
						sai1(new_d_buf[2 * i], new_d_buf[2 * i + 1], cst[s], cst2[s], i); //��A�����̌X���ƐؕЂ��v�Z
						printf("%lf\t%lf\n", cst[s][i], cst2[s][i]);

						//s1[i] = (-1.0*cst[i][0]*cst[i][1]/(cst[i][0]*cst[i][0]+1.0));
						///s2[i] = (cst[i][1]/(cst[i][0]*cst[i][0]+1.0));
					}
				}

				for (i = 0; i < 2 * NUM_SEND; i++) {
					for (j = 0; j < calib_point; j++) {
						cmp_data[i][j + s*calib_point] = d_buf2[i][j];
						//printf("%lf\n",d_buf2[i][j]);
					}
				}
				///exit(0);
			}

			//exit(0);
			for (s = 0; s < FILENUM; s++)
			{
				for (j = 0; j < NUM_SEND; j++)
				{
					for (i = 0; i < calib_point; i++)
					{
						old_mean_data[j][i + s*calib_point] = pow((pow(cmp_data[2 * j][i + s*calib_point], 2.0)
							+ pow(cmp_data[2 * j + 1][i + s*calib_point], 2.0)), 0.5);//�]���̎�M�M���l�̌v�Z

						if (cmp_data[2 * j][i + s*calib_point] > 0.0)
							old_mean_data[j][i + s*calib_point] *= 1.0;
						else
							old_mean_data[j][i + s*calib_point] *= -1.0;
					}
				}

			}

			//exit(0);

			if (use_cst_file != 1) {
				/* ��A�������������߂Ɂi�����A�����j�̃f�[�^�������̑傫�����ɕ��ёւ� */
				sort2(new_d_buf_total, d_buf_total);

				for (i = 0; i < NUM_SEND; i++) {
					sai2(new_d_buf_total[2 * i], new_d_buf_total[2 * i + 1], cst_total, cst2_total, i); //��A�����̌X���ƐؕЂ��v�Z
					printf("%lf\t%lf\n", cst_total[i], cst2_total[i]);

					//s1[i] = (-1.0*cst[i][0]*cst[i][1]/(cst[i][0]*cst[i][0]+1.0));
					///s2[i] = (cst[i][1]/(cst[i][0]*cst[i][0]+1.0));
				}

				for (i = 0; i < NUM_SEND; i++) {
					sum = 0.0;
					for (s = 0; s < FILENUM; s++) {
						sum += cst[s][i];
					}
					v[i] = sum / (double)FILENUM;
					//printf("V:%f\n",v[i]);
				}
				if (v_switch == 0)
					fitting2(cmp_data, v, mean_data);//�f�[�^�Z�b�g�Ԃ̕��ς̌X���Ŏʑ�
				else if (v_switch == 1)
					fitting2(cmp_data, cst_total, mean_data); //�S�f�[�^�Z�b�g���狁�߂��X���Ŏʑ�
				else
					fitting3(cmp_data, cst, mean_data);//�f�[�^�Z�b�g���̌X���Ŏʑ�
			}
			else
				fitting2(cmp_data, cst[0], mean_data);


			//exit(0);





			//�t�@�C���o��///

			for (s = 0; s < FILENUM; s++)
			{
				for (i = 0; i < calib_point; i++)
				{
					fprintf(out_fp[s], "%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\n"
						, mean_data[0][i + s*calib_point], mean_data[1][i + s*calib_point], mean_data[2][i + s*calib_point]
						, mean_data[3][i + s*calib_point], mean_data[4][i + s*calib_point], mean_data[5][i + s*calib_point]
						, mean_data[6][i + s * calib_point], mean_data[7][i + s * calib_point]);
					fprintf(old_fp[s], "%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\n"
						, old_mean_data[0][i + s*calib_point], old_mean_data[1][i + s*calib_point], old_mean_data[2][i + s*calib_point]
						, old_mean_data[3][i + s*calib_point], old_mean_data[4][i + s*calib_point], old_mean_data[5][i + s*calib_point]
						, old_mean_data[6][i + s * calib_point], old_mean_data[7][i + s * calib_point]);
				}
				fprintf(out_fp[s], "%lf\t%lf\n", 0.0, 0.0);
				fprintf(old_fp[s], "%lf\t%lf\n", 0.0, 0.0);
			}

			if (use_cst_file != 1) {
				for (s = 0; s < FILENUM; s++) {
					for (i = 0; i < NUM_SEND; i++) {
						fprintf(cst_fp, "%lf\t", cst[s][i]);
					}
					fprintf(cst_fp, "\n");
				}
				fprintf(cst_fp, "\n");

				for (s = 0; s < FILENUM; s++) {
					for (i = 0; i < NUM_SEND; i++) {
						fprintf(cst_fp, "%lf\t", cst2[s][i]);
					}
					fprintf(cst_fp, "\n");
				}
				fprintf(cst_fp, "\n");

				if (v_switch == 1)
					for (i = 0; i < NUM_SEND; i++)
						fprintf(cst_fp, "%lf\t", cst_total[i]);
				fprintf(cst_fp, "\n\n");
				for (i = 0; i < NUM_SEND; i++)
					fprintf(cst_fp, "%lf\t", cst2_total[i]);
				fprintf(cst_fp, "\n");
			}

			//exit(0);


			//scanf("%d",&i);

			for (s = 0; s < FILENUM; s++)
			{
				fclose(in_fp[s]);
				fclose(out_fp[s]);
				fclose(old_fp[s]);
			}

			fclose(cst_fp);
		}
	}

	free_matrix(d_buf, 2 * NUM_SEND);	
	free_matrix(d_buf2, 2 * NUM_SEND);
	free_matrix(new_d_buf, 2 * NUM_SEND);
	free_matrix(mean_data, NUM_SEND);
	free_matrix(old_mean_data, NUM_SEND);
	free_matrix(cst,FILENUM);
	free_matrix(cmp_data, 2 * NUM_SEND);
	free_matrix(cst2,FILENUM);

        return 0;
}